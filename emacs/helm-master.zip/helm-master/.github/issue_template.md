## Expected behavior


## Actual behavior from `emacs-helm.sh` if possible (See note at bottom)


## Steps to reproduce (recipe)


## Backtraces if some (M-x toggle-debug-on-error)


## Describe versions of helm, emacs, operating system etc.


## IMPORTANT NOTE:

If you are using a Unix or GNU-Linux system there is no excuses 
to not use `emacs-helm.sh` to reproduce your bug in 99% of the cases.
